<?php
$DSN='mysql:host = localhost; dbname=user_management_crud';
$ConnectingDB = new PDO($DSN,'root','');
?>
